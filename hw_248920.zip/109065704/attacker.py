import torch
from torch.nn.parameter import Parameter
from torch.nn.modules.module import Module
from copy import deepcopy
import torch.nn.functional as F
import numpy as np
#from copy import deepcopy
import os.path as osp
import scipy.sparse as sp
from numba import jit
import json


class BaseAttack(Module):
    """Abstract base class for target attack classes.
    Parameters
    ----------
    model :
        model to attack
    nnodes : int
        number of nodes in the input graph
    attack_structure : bool
        whether to attack graph structure
    attack_features : bool
        whether to attack node features
    device: str
        'cpu' or 'cuda'
    """

    def __init__(self, model, nnodes, attack_structure=True, attack_features=False, device='cpu'):
        super(BaseAttack, self).__init__()

        self.surrogate = model
        self.nnodes = nnodes
        self.attack_structure = attack_structure
        self.attack_features = attack_features
        self.device = device

        if model is not None:
            self.nclass = model.nclass
            self.nfeat = model.nfeat
            self.hidden_sizes = model.hidden_sizes

        self.modified_adj = None
        self.modified_features = None

    def attack(self, ori_adj, n_perturbations, **kwargs):
        """Generate perturbations on the input graph.
        Parameters
        ----------
        ori_adj : scipy.sparse.csr_matrix
            Original (unperturbed) adjacency matrix.
        n_perturbations : int
            Number of perturbations on the input graph. Perturbations could
            be edge removals/additions or feature removals/additions.
        Returns
        -------
        None.
        """
        pass

    def check_adj(self, adj):
        """Check if the modified adjacency is symmetric and unweighted.
        """

        if type(adj) is torch.Tensor:
            adj = adj.cpu().numpy()
        assert np.abs(adj - adj.T).sum() == 0, "Input graph is not symmetric"
        if sp.issparse(adj):
            assert adj.tocsr().max() == 1, "Max value should be 1!"
            assert adj.tocsr().min() == 0, "Min value should be 0!"
        else:
            assert adj.max() == 1, "Max value should be 1!"
            assert adj.min() == 0, "Min value should be 0!"

    def save_adj(self, root=r'/tmp/', name='mod_adj'):
        """Save attacked adjacency matrix.
        Parameters
        ----------
        root :
            root directory where the variable should be saved
        name : str
            saved file name
        Returns
        -------
        None.
        """
        assert self.modified_adj is not None, \
                'modified_adj is None! Please perturb the graph first.'
        name = name + '.npz'
        modified_adj = self.modified_adj

        if type(modified_adj) is torch.Tensor:
            sparse_adj = to_scipy(modified_adj)
            sp.save_npz(osp.join(root, name), sparse_adj)
        else:
            sp.save_npz(osp.join(root, name), modified_adj)

    def save_features(self, root=r'/tmp/', name='mod_features'):
        """Save attacked node feature matrix.
        Parameters
        ----------
        root :
            root directory where the variable should be saved
        name : str
            saved file name
        Returns
        -------
        None.
        """

        assert self.modified_features is not None, \
                'modified_features is None! Please perturb the graph first.'
        name = name + '.npz'
        modified_features = self.modified_features

        if type(modified_features) is torch.Tensor:
            sparse_features = to_scipy(modified_features)
            sp.save_npz(osp.join(root, name), sparse_features)
        else:
            sp.save_npz(osp.join(root, name), modified_features)


class RND(BaseAttack):
    """As is described in Adversarial Attacks on Neural Networks for Graph Data (KDD'19),
    'RND is an attack in which we modify the structure of the graph. Given our target node v,
    in each step we randomly sample nodes u whose label is different from v and
    add the edge u,v to the graph structure
    Parameters
    ----------
    model :
        model to attack
    nnodes : int
        number of nodes in the input graph
    attack_structure : bool
        whether to attack graph structure
    attack_features : bool
        whether to attack node features
    device: str
        'cpu' or 'cuda'
    Examples
    --------
    >>> from dataset import Dataset
    >>> from attacker import RND
    >>> data = Dataset(root='/tmp/', name='cora')
    >>> adj, features, labels = data.adj, data.features, data.labels
    >>> idx_train, idx_val, idx_test = data.idx_train, data.idx_val, data.idx_test
    >>> # Setup Attack Model
    >>> target_node = 0
    >>> model = RND()
    >>> # Attack
    >>> model.attack(adj, labels, idx_train, target_node, n_perturbations=5)
    >>> modified_adj = model.modified_adj
    >>> modified_features = model.modified_features
    """

    def __init__(self, model=None, nnodes=None, attack_structure=True, attack_features=True, device='cpu'):
        super(RND, self).__init__(model, nnodes, attack_structure=attack_structure, attack_features=attack_features, device=device)

    def attack(self, ori_features, ori_adj, labels, idx_train, target_node, n_perturbations, **kwargs):
        """
        Randomly sample nodes u whose label is different from v and
        add the edge u,v to the graph structure. This baseline only
        has access to true class labels in training set
        Parameters
        ----------
        ori_features : scipy.sparse.csr_matrix
            Origina (unperturbed) node feature matrix.
        ori_adj : scipy.sparse.csr_matrix
            Original (unperturbed) adjacency matrix
        labels :
            node labels
        idx_train :
            ndarray
            node training indices
        target_node : int
            target node index to be attacked
        n_perturbations : int
            Number of perturbations on the input graph. Perturbations could
            be edge removals/additions or feature removals/additions.
        """
        # ori_adj: sp.csr_matrix

        print('number of pertubations: %s' % n_perturbations)
        modified_adj = ori_adj.tolil()
        modified_features = ori_features.tolil()

        row = ori_adj[target_node].todense().A1 # A1: flatten to 1D array
        # get nodes available for attack
        diff_label_nodes = [x for x in idx_train if labels[x] != labels[target_node] and row[x] == 0]
        # below is where we do the random sampling
        diff_label_nodes = np.random.permutation(diff_label_nodes)
        remain = len(diff_label_nodes) - n_perturbations
        
        
        if remain >= 0: # node available for attack > n_perturbations
            changed_nodes = diff_label_nodes[: n_perturbations ]
            modified_adj[target_node, changed_nodes] = 1  # <-- fancy indexing is used
            # fancy indexing: https://jakevdp.github.io/PythonDataScienceHandbook/02.07-fancy-indexing.html
            # basically: the first array/number in fancy indexing refer to rows, the second refers to row
            modified_adj[changed_nodes, target_node] = 1
            # (adding edge from changed nodes -> target_node; from target_node -> changed nodes, as the graph is undirected)
        else: # labelled nodes not enough for perturbation --> use some unlabelled nodes as well
            changed_nodes = diff_label_nodes
            unlabeled_nodes = [x for x in range(ori_adj.shape[0]) if x not in idx_train and row[x] == 0]
            unlabeled_nodes = np.random.permutation(unlabeled_nodes)
            changed_nodes = np.concatenate([changed_nodes, unlabeled_nodes[: remain]])
            modified_adj[target_node, changed_nodes] = 1
            modified_adj[changed_nodes, target_node] = 1

        self.check_adj(modified_adj)
        self.modified_adj = modified_adj
        self.modified_features = modified_features


#class Nettack_(BaseAttack):
class Nettack_(Module):
    """
    Nettack class used for poisoning attacks on node classification models.
    Copyright (C) 2018
    Daniel Zügner
    Technical University of Munich
    """

    # def __init__(self, model=None, nnodes=None, attack_structure=True, attack_features=True, device='cpu'):
    #     super(Nettack_, self).__init__(model, nnodes, attack_structure=attack_structure,\
    #         attack_features=attack_features, device=device)
        # from BaseAttack __init__:
        # self.surrogate = model
        # self.nnodes = nnodes
        # self.attack_structure = attack_structure
        # self.attack_features = attack_features
        # self.device = device

        # if model is not None:
        #     self.nclass = model.nclass
        #     self.nfeat = model.nfeat
        #     self.hidden_sizes = model.hidden_sizes

        # self.modified_adj = None
        # self.modified_features = None
    
    # def attack(self, ori_features, ori_adj, labels, idx_train, target_node, n_perturbations, **kwargs):
    # def attack_surrogate(self, n_perturbations, perturb_structure=True, perturb_features=False,
    #                     direct=True):

    def __init__(self, adj, X_obs, z_obs, idx_train, W1, W2, target_node, \
        n_perturbations, model=None, nnodes=None, perturb_structure=True, device='cpu'):

        super(Nettack_, self).__init__()
        assert n_perturbations > 0, "need at least one perturbation"

        self.adj = adj.copy().tolil()
        self.adj_orig = self.adj.copy().tolil()
        self.target_node = target_node  # the node being attacked
        self.adj_preprocessed = preprocess_graph(self.adj).tolil()
        self.n_perturbations = n_perturbations
        # Number of nodes
        self.N = adj.shape[0]

        # Node attributes (features)
        self.X_obs = X_obs.copy().tolil() 
        self.X_obs_orig = self.X_obs.copy().tolil()
        # z_obs: Node labels
        self.z_obs = z_obs.copy()
        self.idx_train = idx_train
        self.label_u = self.z_obs[self.target_node] # u: node to attack --> label_u: class label of node u
        self.K = np.max(self.z_obs)+1 #K: num of classes (labels)
        # GCN weight matrices
        self.W1 = W1
        self.W2 = W2
        #print(W1.shape, W2.shape)
        #self.W = sp.csr_matrix(torch.tensordot(self.W1, self.W2, dims=([1], [0])))
        self.W = torch.tensordot(self.W1, self.W2, dims=([1], [0]))

        self.surrogate = model
        self.nnodes = nnodes
        self.perturb_structure = perturb_structure
        self.device = device
        self.target_node = target_node

        if model is not None:
            self.nclass = model.nclass
            self.nfeat = model.nfeat
            self.hidden_sizes = model.hidden_sizes

        self.modified_adj = None
        self.modified_features = None

        self.structure_perturbations = []
        self.best_edge_indices = []

        self.potential_edges = []

    def gradient_wrt_x(self, label):
        """
        Compute the gradient of the logit belonging to the class of the input 
        label with respect to the input features.

        Parameters
        ----------
        label: int
            Class whose logits are of interest

        Returns
        -------
        np.array [N, D] matrix containing the gradients.

        """

        return self.adj_preprocessed.dot(self.adj_preprocessed)[self.target_node].T.dot(self.W[:, label].T)

    def compute_logits(self):
        """
        Compute the logits of the surrogate model, i.e. linearized GCN.
        logit: basically the log probabilities
        Returns
        -------
        np.array, [N, K]
            The log probabilities for each node.

        """
        # uth row of (A^2)*XW1W2
        res = self.adj_preprocessed.dot(self.adj_preprocessed).dot(self.X_obs.dot(self.W.detach().numpy()))[self.target_node]

        return res

    def strongest_wrong_class(self, logits):
        """
        Determine the incorrect class with largest logits.
        largest logits -- largest log prob

        Parameters
        ----------
        logits: np.array, [N, K]
            The input logits

        Returns
        -------
        np.array, [N, L]
            The indices of the wrong labels with the highest attached log probabilities.
        """

        label_u_onehot = np.eye(self.K)[self.label_u] #label_u: class label of node being attacked
        # above: one-hot label of uth node
        #####print((logits - 1000*label_u_onehot).shape) 

        return (logits - 1000*label_u_onehot).argmax() # returns the index (argmax) where max log prob is obtained
        # minus 1000*oneshot because we don't want to return the index of u itself

    def struct_score(self, a_hat_uv, XW):
        """
        Compute structure scores, cf. Eq. 15 in the paper

        Parameters
        ----------
        a_hat_uv: sp.sparse_matrix, shape [P,2]
            Entries of matrix A_hat^2_u for each potential edge (see paper for explanation)

        XW: sp.sparse_matrix, shape [N, K], dtype float
            The class logits for each node.

        Returns
        -------
        np.array [P,]
            The struct score for every row in a_hat_uv
        """

        logits = a_hat_uv.dot(XW) # (A_uv)^2 dot XW
        label_onehot = np.eye(XW.shape[1])[self.label_u] #label_u: class label of node being attacked
        # above: one-hot class(?) label for attacked node
        best_wrong_class_logits = (logits - 1000 * label_onehot).max(1) 
        # np.ndarray.max(axis): get max along given axis (axis is basically dimensio; for 2d array: 0 = row, 1 = col)
        # so here: max of all rows, i.e. max prob for all node features
        # minus 1000* one-hot label: subtract the ground truth prob
        logits_for_correct_class = logits[:,self.label_u]
        # all nodes -> node u
        struct_scores = logits_for_correct_class - best_wrong_class_logits

        return struct_scores

    def compute_XW(self):
        """
        Shortcut to compute the dot product of X and W
        Returns
        -------
        X.dot(W)
        """

        return self.X_obs.dot(self.W.detach().numpy())
        
    def compute_new_a_hat_uv(self, potential_edges):
        """
        Compute the updated A_hat_square_uv entries that would result from 
        inserting/deleting the input edges,
        for every edge.

        Parameters
        ----------
        potential_edges: np.array, shape [P,2], dtype int
            The edges to check.

        Returns
        -------
        sp.sparse_matrix: updated A_hat_square_u entries, a sparse PxN matrix, where P is len(possible_edges).
        """

        edges = np.array(self.adj.nonzero()).T
        edges_set = {tuple(x) for x in edges}
        A_hat_sq = self.adj_preprocessed @ self.adj_preprocessed
        values_before = A_hat_sq[self.target_node].toarray()[0]
        node_ixs = np.unique(edges[:, 0], return_index=True)[1]
        twohop_ixs = np.array(A_hat_sq.nonzero()).T
        degrees = self.adj.sum(0).A1 + 1

        ixs, vals = compute_new_a_hat_uv(edges, node_ixs, edges_set, twohop_ixs, values_before, degrees,
                                         potential_edges, self.target_node)
        ixs_arr = np.array(ixs)
        
        a_hat_uv = sp.coo_matrix((vals, (ixs_arr[:, 0], ixs_arr[:, 1])), shape=[len(potential_edges), self.N])

        return a_hat_uv

    def attack_surrogate(self, verbose=False):
        """
        Perform an attack on the surrogate model.

        Parameters
        ----------
        n_perturbations: int
            The number of perturbations (structure or feature) to perform.
        Returns
        -------
        None.

        """

        # X_obs: features; z_obs: labels
        # Adjacency matrix
        
        print('number of pertubations: %s' % self.n_perturbations)

        logits_start = self.compute_logits() # get (A^2)*XW (i.e. log prob of all nodes)
        best_wrong_class = self.strongest_wrong_class(logits_start)
        ### print(logits_start.shape, self.label_u, best_wrong_class)
        surrogate_losses = [logits_start[self.label_u] - logits_start.flatten()[best_wrong_class]]

        if verbose:
            print("##### Starting attack #####")
            #print("##### Attacking the node directly, with structure perturbation #####")
            #print("##### Performing {} perturbations #####".format(self.n_perturbations))

        if self.target_node in self.idx_train:
            self.potential_edges = np.column_stack((np.tile(self.target_node, len(self.idx_train)-1), np.setdiff1d(self.idx_train, self.target_node)))
        else:
            self.potential_edges = np.column_stack((np.tile(self.target_node, len(self.idx_train)), np.setdiff1d(self.idx_train, self.target_node)))
        #self.potential_edges = torch.FloatTensor(self.potential_edges).type(torch.float32)

        for _ in range(self.n_perturbations):
            if verbose:
                print("##### ...{}/{} perturbations ... #####".format(_+1, self.n_perturbations))
            if self.perturb_structure:

                # Do not consider edges that, if removed, result in singleton edges in the graph.
                #singleton_filter = filter_singletons(self.potential_edges, self.adj)
                #filtered_edges = self.potential_edges[singleton_filter]

                filtered_edges = self.potential_edges.copy()
                #print(self.best_edge_indices[:10])
                for idx in self.best_edge_indices:
                    filtered_edges = np.delete(self.potential_edges, idx, axis=0)

                #print("filtered_edges shape:", filtered_edges.shape)

                filtered_edges = torch.FloatTensor(filtered_edges).type(torch.float32)

                # Compute new entries in A_hat_square_uv 
                a_hat_uv_new = self.compute_new_a_hat_uv(filtered_edges)

                # b = a_hat_uv_new.tolil().data
                # snp.save("a_hat_uv_new.npy", b)
                # Compute the struct scores for each potential edge
                struct_scores = self.struct_score(a_hat_uv_new, self.compute_XW())
                best_edge_ix = struct_scores.argmin()
                best_edge_score = struct_scores.min()
                best_edge = filtered_edges[best_edge_ix]
                change_structure = True

            if change_structure: # perturb only when perturb_structure and perturb_features are both True??
                # perform edge perturbation

                #print("best edge: ", best_edge)
                #print(self.adj[tuple(best_edge)])
                #print(self.adj[tuple(torch.flip(best_edge, [0]))])
                self.adj[tuple(best_edge)] = 1 - self.adj[tuple(best_edge)]
                self.adj[tuple(torch.flip(best_edge, [0]))] = 1 - self.adj[tuple(best_edge)]
                # [::-1] returns a reversed list

                self.adj_preprocessed = preprocess_graph(self.adj)

                self.structure_perturbations.append(tuple(best_edge))
                self.best_edge_indices.append(best_edge_ix)
                surrogate_losses.append(best_edge_score)

    def reset(self):
        """
        Reset Nettack
        """
        self.adj = self.adj_orig.copy()
        self.X_obs = self.X_obs_orig.copy()
        self.structure_perturbations = []
        self.potential_edges = []


# def filter_singletons(edges, adj):
#     """
#     Filter edges that, if removed, would turn one or more nodes into singleton nodes.

#     Parameters
#     ----------
#     edges: np.array, shape [P, 2], dtype int, where P is the number of input edges.
#         The potential edges.

#     adj: sp.sparse_matrix, shape [N,N]
#         The input adjacency matrix.

#     Returns
#     -------
#     np.array, shape [P, 2], dtype bool:
#         A binary vector of length len(edges), False values indicate that the edge at
#         the index  generates singleton edges, and should thus be avoided.

#     """

#     degs = np.squeeze(np.array(np.sum(adj,0)))
#     # adj_csr = adj.tocsr().copy()
#     #print(adj.tocsr().flags)

#     print(adj.tocsr()[0])
#     tp = tuple(edges.T)
#     existing_edges = adj.tocsr()[tp]
#     existing_edges = np.squeeze(np.array(adj.tocsr()[tuple(edges.T)]))
#     if existing_edges.size > 0:
#         edge_degrees = degs[np.array(edges)] + 2*(1-existing_edges[:,None]) - 1
#     else:
#         edge_degrees = degs[np.array(edges)] + 1

#     zeros = edge_degrees == 0
#     zeros_sum = zeros.sum(1)
#     return zeros_sum == 0

#@jit(nopython=True)
#@torch.jit.script
def connected_after(u, v, connected_before, delta):
    if u == v:
        if delta == -1:
            return False
        else:
            return True
    else:
        return connected_before


#@jit(nopython=True)
#@torch.jit.script
def compute_new_a_hat_uv(edge_ixs, node_nb_ixs, edges_set, twohop_ixs, values_before, degs, potential_edges, u):
    """
    Compute the new values [A_hat_square]_u for every potential edge, where u is the target node. C.f. Theorem 5.1
    equation 17.

    Parameters
    ----------
    edge_ixs: np.array, shape [E,2], where E is the number of edges in the graph.
        The indices of the nodes connected by the edges in the input graph.
    node_nb_ixs: np.array, shape [N,], dtype int
        For each node, this gives the first index of edges associated to this node in the edge array (edge_ixs).
        This will be used to quickly look up the neighbors of a node, since numba does not allow nested lists.
    edges_set: set((e0, e1))
        The set of edges in the input graph, i.e. e0 and e1 are two nodes connected by an edge
    twohop_ixs: np.array, shape [T, 2], where T is the number of edges in A_tilde^2
        The indices of nodes that are in the twohop neighborhood of each other, including self-loops.
    values_before: np.array, shape [N,], the values in [A_hat]^2_uv to be updated.
    degs: np.array, shape [N,], dtype int
        The degree of the nodes in the input graph.
    potential_edges: np.array, shape [P, 2], where P is the number of potential edges.
        The potential edges to be evaluated. For each of these potential edges, this function will compute the values
        in [A_hat]^2_uv that would result after inserting/removing this edge.
    u: int
        The target node

    Returns
    -------
    return_ixs: List of tuples
        The ixs in the [P, N] matrix of updated values that have changed
    return_values:

    """
    N = int(degs.shape[0])

    # edge_ixs: nodes withing 1hop distance of each other
    # twohop_ixs: nodes within 2hop distance of each other
    # twohop_u: nodes withing 2 hops of u
    twohop_u = twohop_ixs[twohop_ixs[:, 0] == u, 1]
    nbs_u = edge_ixs[edge_ixs[:, 0] == u, 1]
    nbs_u_set = set(nbs_u)

    return_ixs = []
    return_values = []

    for ix in range(len(potential_edges)):
        edge = potential_edges[ix] # ith edge
        edge_set = set(edge)
        degs_new = degs.copy()
        delta = -2 * ((edge[0], edge[1]) in edges_set) + 1
        degs_new[edge[0].int()] += delta
        degs_new[edge[1].int()] += delta

        nbs_edge0 = []
        nbs_edge1 = []
        for e in edge_ixs:
            if e[0] == edge[0]:
                nbs_edge0.append(e[1])
            if e[0]  == edge[1]:
                nbs_edge1.append(e[1])
        nbs_edge0 = np.asarray(nbs_edge0)
        nbs_edge1 = np.asarray(nbs_edge1)
        # edge_ixs: shape = (num of edges, 2); row: (from, to), col: edge elements
        #nbs_edge0 = edge_ixs[edge_ixs[:, 0] == edge[0].int(), 1]
        #nbs_edge1 = edge_ixs[edge_ixs[:, 0] == edge[1].int(), 1]
        # numpy array indicing, see: https://jakevdp.github.io/PythonDataScienceHandbook/02.02-the-basics-of-numpy-arrays.html

        affected_nodes = set(np.concatenate((twohop_u, nbs_edge0, nbs_edge1), axis=0))
        affected_nodes = affected_nodes.union(edge_set)
        a_um = edge[0] in nbs_u_set
        a_un = edge[1] in nbs_u_set

        a_un_after = connected_after(int(u), int(edge[0]), a_un, delta)
        a_um_after = connected_after(int(u), int(edge[1]), a_um, delta)

        for v in affected_nodes:
            a_uv_before = v in nbs_u_set
            a_uv_before_sl = a_uv_before or v == u

            if v in edge_set and u in edge_set and u != v:
                if delta == -1:
                    a_uv_after = False
                else:
                    a_uv_after = True
            else:
                a_uv_after = a_uv_before
            a_uv_after_sl = a_uv_after or v == u

            from_ix = node_nb_ixs[int(v)]
            to_ix = node_nb_ixs[int(v) + 1] if v < N - 1 else len(edge_ixs)
            node_nbs = edge_ixs[from_ix:to_ix, 1]
            node_nbs_set = set(node_nbs)
            a_vm_before = edge[0] in node_nbs_set

            a_vn_before = edge[1] in node_nbs_set
            a_vn_after = connected_after(v, edge[0], a_vn_before, delta)
            a_vm_after = connected_after(v, edge[1], a_vm_before, delta)

            mult_term = 1 / np.sqrt(degs_new[u] * degs_new[int(v)])

            sum_term1 = np.sqrt(degs[u] * degs[int(v)]) * values_before[int(v)] - a_uv_before_sl / degs[u] - a_uv_before / \
                        degs[int(v)]
            sum_term2 = a_uv_after / degs_new[int(v)] + a_uv_after_sl / degs_new[u]
            sum_term3 = -((a_um and a_vm_before) / degs[edge[0].int()]) + (a_um_after and a_vm_after) / degs_new[edge[0].int()]
            sum_term4 = -((a_un and a_vn_before) / degs[edge[1].int()]) + (a_un_after and a_vn_after) / degs_new[edge[1].int()]
            new_val = mult_term * (sum_term1 + sum_term2 + sum_term3 + sum_term4)

            return_ixs.append((ix, v))
            return_values.append(new_val)
    return return_ixs, return_values


####################################################
# utils
####################################################

from sklearn.model_selection import train_test_split
from scipy.sparse.csgraph import connected_components


def preprocess_graph(adj):
    # returns a normalised matrix with self loop

    adj_ = adj + sp.eye(adj.shape[0]) # add self loop
    rowsum = adj_.sum(1).A1 # flatten matrix to 1d array
    degree_mat_inv_sqrt = sp.diags(np.power(rowsum, -0.5))
    # .diags: construct sparse matrix from diagonals, default offset=0,
    # i.e. the constructed matrix would have the input array as main diagonal (and other elements = 0)
    adj_normalized = adj_.dot(degree_mat_inv_sqrt).T.dot(degree_mat_inv_sqrt).tocsr()
    # dot: matrix multiplication; T: transpose
    # tocsr: to compact sparse row matrx storage method (cf. coo)
    return adj_normalized


def is_sparse_tensor(tensor):
    """Check if a tensor is sparse tensor.
    Parameters
    ----------
    tensor : torch.Tensor
        given tensor
    Returns
    -------
    bool
        whether a tensor is sparse tensor
    """
    # if hasattr(tensor, 'nnz'):
    if tensor.layout == torch.sparse_coo:
        return True
    else:
        return False

def to_scipy(tensor):
    """Convert a dense/sparse tensor to scipy matrix"""
    if is_sparse_tensor(tensor):
        values = tensor._values()
        indices = tensor._indices()
        return sp.csr_matrix((values.cpu().numpy(), indices.cpu().numpy()), shape=tensor.shape)
    else:
        indices = tensor.nonzero().t()
        values = tensor[indices[0], indices[1]]
        return sp.csr_matrix((values.cpu().numpy(), indices.cpu().numpy()), shape=tensor.shape)
